import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Task2_Mapper extends Mapper<Object,Text,Text,IntWritable>{
	
	// Map Job to calculate Total TV sales per brand
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		//Converting the read line to String
		String temp_value = value.toString();
		
		System.out.println("Value in mapper : "+temp_value);
		
		// Do operation only if read line does not contains invalid record denoted by NA
		if (!(temp_value.contains("|NA")  ||
			  temp_value.contains("|NA|") ||
			  temp_value.contains("NA|")))
		{
			// Extract company Name which will be till first "|"
			String tv_brand = temp_value.split("\\|")[0];
			
			//Write the Tv Brand Name along with 1, to denote the number of sale 
			context.write(new Text(tv_brand), new IntWritable(1));
		}
	}
}
