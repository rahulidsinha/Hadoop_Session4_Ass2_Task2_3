import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Task2_Reducer extends Reducer<Text,IntWritable,Text,IntWritable> {
	
	// Reducer Job to calculate Total TV sales per brand
	public void reduce(Text key, Iterable<IntWritable>value, Context context) throws IOException, InterruptedException
	{
		int count = 0;
		
		// Iterate till all the value of a key are covered
		while(value.iterator().hasNext())
		{
			IntWritable temp_value = value.iterator().next();
			count = count + temp_value.get();
		}
		// Write the tv_brand_name along with total sales
		context.write(key, new IntWritable(count));
	}
}
