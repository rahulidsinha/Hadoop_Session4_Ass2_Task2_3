import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Task3_reducer extends Reducer<Text,IntWritable,Text,IntWritable>{
	public void reduce(Text key, Iterable<IntWritable>value, Context context) throws IOException, InterruptedException
	{
		int count = 0;
		
		// Iterate till all the value for a key are covered
		while(value.iterator().hasNext())
		{
			IntWritable temp_value = value.iterator().next();
			count = count + temp_value.get();
		}
		// Write the State of sale along with total sales for Onida company
		context.write(key, new IntWritable(count));
	}
}
