import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Task3_mapper extends Mapper<Object,Text,Text,IntWritable>{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		// Sample Value : Onida|Lucid|18|Uttar Pradesh|232401|16200
		//Converting the read line to String
		String temp = value.toString();
		
		// Do operation only if read line does not contains invalid record denoted by NA
		if (!(temp.contains("|NA") || 
			  temp.contains("|NA|")|| 
			  temp.contains("NA|")))
		{	
			// Extract company Name which will be till first "|"
			String tv_brand = temp.split("\\|")[0];
			
			// Do action only if Brand name is Onida
			if (tv_brand.equalsIgnoreCase("Onida"))
			{
				// Extract State of sale which will be till 4th "|"
				String state_of_sale = temp.split("\\|")[3];
				
				//Write the State along with 1, to denote the number of sale in that state 
				context.write(new Text(state_of_sale), new IntWritable(1));
			}
			
		}
	}
}
