import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;

public class Task3_driver extends Configured{

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException  {
		
		//Creating Configuration object and Job Object
		Configuration conf = new Configuration();
		Job job =Job.getInstance(conf, "Onida State-wise Sales Report ");
		
		// Setting Main class, Map and Reduce class 
		job.setJarByClass(Task3_driver.class);
		job.setMapperClass(Task3_mapper.class);
		job.setReducerClass(Task3_reducer.class);
		
		// Setting Map Output Key, value type
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		//Setting Reducer Output Key, value type
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		//Setting Input and Output Directory
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		//System.exit() will return 0 on successful execution, else -1
		System.exit(job.waitForCompletion(true) ? 0 : -1);

	}

}
